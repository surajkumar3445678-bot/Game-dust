package com.ultimate.nonrootbooster

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.BatteryManager
import android.os.Bundle
import android.os.Environment
import android.os.StatFs
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.io.File
import java.util.Locale

private val Bg = Color(0xFF050A18)
private val Panel = Color(0xFF101B35)
private val Blue = Color(0xFF13BFFF)
private val Purple = Color(0xFF8B4DFF)
private val Cyan = Color(0xFF00E5FF)
private val Green = Color(0xFF35E879)
private val Muted = Color(0xFF9FB1D3)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { BoosterApp(this) }
    }
}

data class GameApp(val name: String, val packageName: String, val icon: android.graphics.drawable.Drawable)
data class DeviceStats(
    val ramUsed: Long,
    val ramTotal: Long,
    val storageUsed: Long,
    val storageTotal: Long,
    val batteryLevel: Int,
    val batteryTemp: Float?,
    val cpuFreq: String
)

private fun readStats(context: Context): DeviceStats {
    val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    val mem = ActivityManager.MemoryInfo()
    am.getMemoryInfo(mem)
    val battery = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
    val level = battery?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
    val scale = battery?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
    val pct = if (level >= 0 && scale > 0) (level * 100 / scale) else 0
    val tempRaw = battery?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) ?: -1
    val temp = if (tempRaw > 0) tempRaw / 10f else null
    val stat = StatFs(Environment.getDataDirectory().path)
    val total = stat.totalBytes
    val free = stat.availableBytes
    val freqFile = File("/sys/devices/system/cpu/cpu0/cpufreq/scaling_cur_freq")
    val freq = try {
        if (freqFile.canRead()) "${freqFile.readText().trim().toLong() / 1000} MHz" else "Unavailable"
    } catch (_: Exception) { "Unavailable" }
    return DeviceStats(
        (mem.totalMem - mem.availMem).coerceAtLeast(0), mem.totalMem,
        (total - free).coerceAtLeast(0), total, pct, temp, freq
    )
}

private fun formatBytes(n: Long): String {
    if (n <= 0) return "Unavailable"
    val gb = n / 1024.0 / 1024.0 / 1024.0
    return if (gb >= 1) String.format(Locale.US, "%.1f GB", gb)
    else "${n / 1024 / 1024} MB"
}

private fun loadLaunchableApps(context: Context): List<GameApp> {
    val pm = context.packageManager
    val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    @Suppress("DEPRECATION")
    return pm.queryIntentActivities(intent, 0).mapNotNull {
        try {
            GameApp(
                it.loadLabel(pm).toString(),
                it.activityInfo.packageName,
                it.loadIcon(pm)
            )
        } catch (_: Exception) { null }
    }.distinctBy { it.packageName }.sortedBy { it.name.lowercase() }
}

@Composable
fun BoosterApp(context: Context) {
    val tabs = listOf("Home", "Games", "Tools", "Monitor", "Settings")
    val tabIcons = listOf(Icons.Default.Home, Icons.Default.SportsEsports, Icons.Default.Build, Icons.Default.ShowChart, Icons.Default.Settings)
    var selected by remember { mutableStateOf("Home") }
    var stats by remember { mutableStateOf(readStats(context)) }
    var gameMode by remember { mutableStateOf(false) }
    var profile by remember { mutableStateOf("Balanced") }
    var apps by remember { mutableStateOf(emptyList<GameApp>()) }
    var favorites by remember { mutableStateOf(setOf<String>()) }
    var message by remember { mutableStateOf("Ready • Non-root mode") }

    LaunchedEffect(Unit) {
        apps = loadLaunchableApps(context)
        while (true) {
            stats = readStats(context)
            delay(4000)
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Panel, primary = Blue, secondary = Purple,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(
            containerColor = Bg,
            bottomBar = {
                NavigationBar(containerColor = Color(0xFF081126)) {
                    tabs.forEachIndexed { i, tab ->
                        NavigationBarItem(
                            selected = selected == tab,
                            onClick = { selected = tab },
                            icon = { Icon(tabIcons[i], null) },
                            label = { Text(tab, fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Cyan,
                                selectedTextColor = Cyan,
                                indicatorColor = Color(0xFF17365C),
                                unselectedIconColor = Muted,
                                unselectedTextColor = Muted
                            )
                        )
                    }
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding)) {
                Header()
                when (selected) {
                    "Home" -> HomeScreen(stats, gameMode, { gameMode = it }, profile, { profile = it }, apps.filter { favorites.contains(it.packageName) }, { app -> launchApp(context, app.packageName) }, message)
                    "Games" -> GamesScreen(apps, favorites, { favorites = if (favorites.contains(it)) favorites - it else favorites + it }, { launchApp(context, it) }, { openAppSettings(context, it) })
                    "Tools" -> ToolsScreen(context, apps, stats) { message = it }
                    "Monitor" -> MonitorScreen(stats)
                    else -> SettingsScreen(context, profile, { profile = it }, { message = it })
                }
            }
        }
    }
}

private fun launchApp(context: Context, pkg: String) {
    try {
        context.packageManager.getLaunchIntentForPackage(pkg)?.let {
            it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(it)
        }
    } catch (_: Exception) {}
}

private fun openAppSettings(context: Context, pkg: String) {
    val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg"))
    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    context.startActivity(intent)
}

@Composable
private fun Header() {
    Row(
        Modifier.fillMaxWidth().background(Brush.horizontalGradient(listOf(Color(0xFF10244A), Color(0xFF10102B)))).padding(15.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column {
            Text("ULTIMATE", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Black)
            Text("GAME BOOSTER", color = Cyan, fontSize = 22.sp, fontWeight = FontWeight.Black)
            Text("FASTER • SMOOTHER • SMARTER", color = Muted, fontSize = 9.sp)
        }
        Column(horizontalAlignment = Alignment.End) {
            Text("NON-ROOT MODE", color = Green, fontWeight = FontWeight.Bold, fontSize = 11.sp)
            Text("Android compatible", color = Muted, fontSize = 10.sp)
        }
    }
}

@Composable
private fun HomeScreen(
    stats: DeviceStats, gameMode: Boolean, onGameMode: (Boolean) -> Unit,
    profile: String, onProfile: (String) -> Unit, favorites: List<GameApp>,
    onLaunch: (GameApp) -> Unit, message: String
) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(13.dp), verticalArrangement = Arrangement.spacedBy(11.dp)) {
        item {
            NeonCard {
                Column(Modifier.fillMaxWidth().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("NON-ROOT GAME OPTIMIZER", color = Cyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Text("🎮", fontSize = 48.sp)
                    Text("READY TO PLAY", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Black)
                    Text("Check your device before launching a game", color = Muted, fontSize = 11.sp)
                    Spacer(Modifier.height(10.dp))
                    Button(onClick = { /* Safe local refresh only; Android manages system scheduling */ },
                        colors = ButtonDefaults.buttonColors(containerColor = Purple)) {
                        Icon(Icons.Default.Bolt, null)
                        Spacer(Modifier.width(6.dp))
                        Text("OPTIMIZE MY SETUP")
                    }
                    Text("No fake FPS boost or forced RAM cleaning.", color = Muted, fontSize = 9.sp)
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatCard("RAM IN USE", formatBytes(stats.ramUsed), "of ${formatBytes(stats.ramTotal)}", Modifier.weight(1f), Cyan)
                StatCard("BATTERY", "${stats.batteryLevel}%", "remaining", Modifier.weight(1f), Green)
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatCard("BATTERY TEMP", stats.batteryTemp?.let { "$it°C" } ?: "N/A", "battery sensor", Modifier.weight(1f), Color(0xFFFFB347))
                StatCard("CPU CLOCK", stats.cpuFreq, "read-only if exposed", Modifier.weight(1f), Purple)
            }
        }
        item {
            NeonCard {
                Row(Modifier.fillMaxWidth().padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("GAME MODE", color = Cyan, fontWeight = FontWeight.Bold)
                        Text(if (gameMode) "Enabled in app" else "Off", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                        Text("Keeps your selected booster profile ready; it cannot change Android kernel scheduling.", color = Muted, fontSize = 9.sp)
                    }
                    Switch(checked = gameMode, onCheckedChange = onGameMode)
                }
            }
        }
        item {
            NeonCard {
                Column(Modifier.padding(13.dp)) {
                    Text("DEVICE PROFILE", color = Cyan, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(7.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        listOf("Balanced", "Gaming", "Battery").forEach { p ->
                            FilterChip(selected = profile == p, onClick = { onProfile(p) }, label = { Text(p, fontSize = 10.sp) })
                        }
                    }
                    Text("Profile saves your preference only; no restricted system settings are modified.", color = Muted, fontSize = 9.sp)
                }
            }
        }
        item {
            NeonCard {
                Column(Modifier.padding(13.dp)) {
                    Text("FAVOURITE GAMES", color = Cyan, fontWeight = FontWeight.Bold)
                    if (favorites.isEmpty()) Text("Open Games and tap the star to add favourites.", color = Muted, fontSize = 10.sp)
                    favorites.take(5).forEach { app ->
                        Row(Modifier.fillMaxWidth().clickable { onLaunch(app) }.padding(vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                            AppIcon(app, 34)
                            Spacer(Modifier.width(10.dp))
                            Text(app.name, Modifier.weight(1f), color = Color.White)
                            Text("PLAY  ›", color = Cyan, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        }
                    }
                }
            }
        }
        item { Text(message, color = Green, fontSize = 10.sp) }
    }
}

@Composable
private fun GamesScreen(
    apps: List<GameApp>, favorites: Set<String>, onFavorite: (String) -> Unit,
    onLaunch: (String) -> Unit, onSettings: (String) -> Unit
) {
    var search by remember { mutableStateOf("") }
    val filtered = apps.filter { it.name.contains(search, true) || it.packageName.contains(search, true) }
    Column(Modifier.fillMaxSize().padding(horizontal = 13.dp)) {
        Text("GAME & APP LIBRARY", color = Cyan, fontWeight = FontWeight.Black, fontSize = 20.sp, modifier = Modifier.padding(vertical = 10.dp))
        OutlinedTextField(value = search, onValueChange = { search = it }, modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("Search installed apps…") }, leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true)
        Text("${filtered.size} launchable apps found • mark games with ☆", color = Muted, fontSize = 10.sp, modifier = Modifier.padding(vertical = 7.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(7.dp)) {
            items(filtered, key = { it.packageName }) { app ->
                NeonCard {
                    Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        AppIcon(app, 42)
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(app.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text(app.packageName, color = Muted, fontSize = 8.sp, maxLines = 1)
                        }
                        IconButton(onClick = { onFavorite(app.packageName) }) {
                            Icon(if (favorites.contains(app.packageName)) Icons.Default.Star else Icons.Default.StarBorder,
                                null, tint = Color(0xFFFFD34E))
                        }
                        IconButton(onClick = { onSettings(app.packageName) }) { Icon(Icons.Default.Settings, null, tint = Muted) }
                        Button(onClick = { onLaunch(app.packageName) }, contentPadding = PaddingValues(horizontal = 10.dp)) { Text("Play", fontSize = 11.sp) }
                    }
                }
            }
        }
    }
}

@Composable
private fun AppIcon(app: GameApp, size: Int) {
    Surface(
        modifier = Modifier.size(size.dp),
        shape = RoundedCornerShape(10.dp),
        color = Color(0xFF17365C),
        border = BorderStroke(1.dp, Cyan)
    ) {
        Box(contentAlignment = Alignment.Center) {
            Text(app.name.take(1).uppercase(), color = Cyan, fontWeight = FontWeight.Black, fontSize = (size / 2).sp)
        }
    }
}

@Composable
private fun ToolsScreen(context: Context, apps: List<GameApp>, stats: DeviceStats, onMessage: (String) -> Unit) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(13.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
        item { Text("QUICK TOOLS", color = Cyan, fontSize = 21.sp, fontWeight = FontWeight.Black) }
        item {
            ToolCard("Clear Booster Cache", "Clears only this booster's temporary cache.", Icons.Default.Delete) {
                val before = context.cacheDir.walkTopDown().filter { it.isFile }.sumOf { it.length() }
                context.cacheDir.deleteRecursively()
                context.cacheDir.mkdirs()
                onMessage("Cleared booster app cache (${formatBytes(before)}). Other apps are unchanged.")
            }
        }
        item { ToolCard("Storage Details", "Used: ${formatBytes(stats.storageUsed)} / ${formatBytes(stats.storageTotal)}", Icons.Default.Storage) {
            context.startActivity(Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } }
        item { ToolCard("App Cache & Storage", "Choose an app in the Games list, then open its Android App Info page.", Icons.Default.Apps) {
            onMessage("Open Games, tap the settings icon beside an app.")
        } }
        item { ToolCard("Battery Settings", "Open Android battery controls.", Icons.Default.BatteryChargingFull) {
            context.startActivity(Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } }
        item { ToolCard("Network Settings", "Open Android network settings; this app cannot amplify signal or bypass carrier limits.", Icons.Default.Wifi) {
            context.startActivity(Intent(Settings.ACTION_WIRELESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } }
        item { ToolCard("Display Settings", "Adjust refresh and brightness using Android settings.", Icons.Default.DisplaySettings) {
            context.startActivity(Intent(Settings.ACTION_DISPLAY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } }
        item { Text("Note: Android does not allow ordinary apps to force-stop other apps or clear their private cache silently.", color = Muted, fontSize = 10.sp) }
    }
}

@Composable
private fun MonitorScreen(stats: DeviceStats) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(13.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
        item { Text("LIVE DEVICE MONITOR", color = Cyan, fontSize = 21.sp, fontWeight = FontWeight.Black) }
        item { Text("Readings refresh every 4 seconds while the app is open.", color = Muted, fontSize = 10.sp) }
        item { StatCard("RAM IN USE", formatBytes(stats.ramUsed), "of ${formatBytes(stats.ramTotal)} total", Modifier.fillMaxWidth(), Cyan) }
        item { StatCard("INTERNAL STORAGE", formatBytes(stats.storageUsed), "of ${formatBytes(stats.storageTotal)} used", Modifier.fillMaxWidth(), Blue) }
        item { StatCard("BATTERY", "${stats.batteryLevel}%", "battery level", Modifier.fillMaxWidth(), Green) }
        item { StatCard("BATTERY TEMPERATURE", stats.batteryTemp?.let { "$it°C" } ?: "Unavailable", "not CPU/GPU junction temperature", Modifier.fillMaxWidth(), Color(0xFFFFB347)) }
        item { StatCard("CPU CLOCK", stats.cpuFreq, "read-only; may be hidden by device", Modifier.fillMaxWidth(), Purple) }
        item { Text("CPU/GPU load, FPS and frame-time telemetry are not exposed consistently to normal third-party apps; unavailable data is not invented.", color = Muted, fontSize = 10.sp) }
    }
}

@Composable
private fun SettingsScreen(context: Context, profile: String, onProfile: (String) -> Unit, onMessage: (String) -> Unit) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(13.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
        item { Text("SETTINGS & ABOUT", color = Cyan, fontSize = 21.sp, fontWeight = FontWeight.Black) }
        item { ToolCard("Mode", "NON-ROOT • No Magisk or superuser access required", Icons.Default.Security) {} }
        item {
            NeonCard {
                Column(Modifier.padding(13.dp)) {
                    Text("Default profile", color = Cyan, fontWeight = FontWeight.Bold)
                    listOf("Balanced", "Gaming", "Battery").forEach { p ->
                        Row(Modifier.fillMaxWidth().clickable { onProfile(p) }.padding(5.dp), verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(selected = profile == p, onClick = { onProfile(p) })
                            Text(p, color = Color.White)
                        }
                    }
                }
            }
        }
        item { ToolCard("Open Android App Settings", "Manage permissions and battery usage.", Icons.Default.Settings) {
            context.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } }
        item { ToolCard("Restore Booster Defaults", "Reset this app's selected profile and favourites for this session.", Icons.Default.Restore) {
            onProfile("Balanced")
            onMessage("Booster profile reset to Balanced.")
        } }
        item {
            NeonCard {
                Column(Modifier.padding(14.dp)) {
                    Text("ULTIMATE GAME BOOSTER", color = Cyan, fontWeight = FontWeight.Black, fontSize = 18.sp)
                    Text("Version 1.0.0 • Non-root edition", color = Muted, fontSize = 11.sp)
                    Text("Designed for safe game organization and device monitoring. No guaranteed FPS increase.", color = Muted, fontSize = 10.sp)
                }
            }
        }
    }
}

@Composable
private fun ToolCard(title: String, subtitle: String, icon: ImageVector, onClick: () -> Unit) {
    NeonCard {
        Row(Modifier.fillMaxWidth().clickable { onClick() }.padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = Cyan, modifier = Modifier.size(29.dp))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Text(subtitle, color = Muted, fontSize = 9.sp)
            }
            Icon(Icons.Default.ChevronRight, null, tint = Muted)
        }
    }
}

@Composable
private fun StatCard(title: String, value: String, detail: String, modifier: Modifier, accent: Color) {
    NeonCard(modifier) {
        Column(Modifier.padding(12.dp)) {
            Text(title, color = accent, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Text(value, color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Black)
            Text(detail, color = Muted, fontSize = 9.sp)
        }
    }
}

@Composable
private fun NeonCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(17.dp),
        colors = CardDefaults.cardColors(containerColor = Panel),
        border = BorderStroke(1.dp, Color(0xFF17639B)),
        content = content
    )
}
